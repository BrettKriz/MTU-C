import org.junit.*;
import jug.*;
import cs2321.*;
import net.datastructures.*;
import java.util.Random;

@jug.SuiteName("Empty Dictionary")
public class emptyListLF {

	private Logfile<String, String> TARGET = init();
	private Logfile<String, String> T = init();

	public Logfile<String, String> init() {
		return new Logfile<String, String>();
	}

	@org.junit.Test(timeout=60000)
	@jug.TestName("Verifying size() = 0")
	public void Test1() throws Throwable {
		
		org.junit.Assert.assertEquals("Verifying size() = 0", (Object)(0), (Object)(TARGET.size()));
	}

	@org.junit.Test()
	@jug.TestName("Verifying isEmpty() = true")
	public void Test2() throws Throwable {
		
		org.junit.Assert.assertEquals("Verifying isEmpty() = true", (Object)(true), (Object)(TARGET.isEmpty()));
	}

	@org.junit.Test()
	@jug.TestName("Entry e = insert(\"50\",\"A\"): Verifying e.getKey() = \"50\"")
	public void Test3() throws Throwable {
		Entry e = TARGET.insert("50","A");
		
		org.junit.Assert.assertEquals("Entry e = insert(\"50\",\"A\"): Verifying e.getKey() = \"50\"", (Object)("50"), (Object)(e.getKey()));
	}

	@org.junit.Test()
	@jug.TestName("Entry e = insert(\"50\",\"A\"): Verifying e.getValue() = \"A\"")
	public void Test4() throws Throwable {
		Entry e = TARGET.insert("50","A");
		
		org.junit.Assert.assertEquals("Entry e = insert(\"50\",\"A\"): Verifying e.getValue() = \"A\"", (Object)("A"), (Object)(e.getValue()));
	}

	@org.junit.Test()
	@jug.TestName("Entry e = insert(\"50\",\"A\"); remove(e): Verifying size() = 0")
	public void Test5() throws Throwable {
		Entry e = TARGET.insert("50","A");
		TARGET.remove(e);
		
		org.junit.Assert.assertEquals("Entry e = insert(\"50\",\"A\"); remove(e): Verifying size() = 0", (Object)(0), (Object)(TARGET.size()));
	}

	@org.junit.Test()
	@jug.TestName("Verifying find(\"1\") returns null")
	public void Test6() throws Throwable {
		
		org.junit.Assert.assertEquals("Verifying find(\"1\") returns null", (Object)(null), (Object)(TARGET.find("1")));
	}

}
