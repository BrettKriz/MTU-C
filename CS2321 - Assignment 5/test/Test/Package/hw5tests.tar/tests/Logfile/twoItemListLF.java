import org.junit.*;
import jug.*;
import cs2321.*;
import net.datastructures.*;
import java.util.Random;

@jug.SuiteName("Two Item List - Entries:{[\"1\",\"A\"],[\"2\",\"B\"]}")
public class twoItemListLF {

	private Logfile<String, String> TARGET = init();
	private Logfile<String, String> T = init();

	public Logfile<String, String> init() {
		return new Logfile<String, String>();
	}

	@Before
	public void setup() throws Throwable {
		TARGET.insert("1","A");
			TARGET.insert("2","B");
	}

	@org.junit.Test(timeout=60000)
	@jug.TestName("Verifying entries() count = 2")
	public void Test1() throws Throwable {
		int count = 0;
		for(Entry<String, String> e : TARGET.entries())
				count++;
		
		org.junit.Assert.assertEquals("Verifying entries() count = 2", (Object)(2), (Object)(count));
	}

	@org.junit.Test()
	@jug.TestName("Verifying entries() contains entries with Keys:{\"1\",\"2\"}")
	public void Test2() throws Throwable {
		String [] keys = {"1","2"}
		;
		Iterable<Entry<String, String>> dictEntries = TARGET.entries();
		boolean [] checked = new boolean[keys.length];
		for(Entry<String,String> e : dictEntries) {
				for(int j=0; j<keys.length; j++) {
					if(keys[j].equals(e.getKey())) {
						checked[j]=true;
					}
				}
			}
		for(int j=0; j<checked.length; j++)//;
		
		org.junit.Assert.assertEquals("Verifying entries() contains entries with Keys:{\"1\",\"2\"}", (Object)(true), (Object)(checked[j]));
	}

	@org.junit.Test()
	@jug.TestName("Verifying entries() contains entries with Values:{\"A\",\"B\"}")
	public void Test3() throws Throwable {
		String [] values = {"A","B"}
		;
		Iterable<Entry<String, String>> dictEntries = TARGET.entries();
		boolean [] checked = new boolean[values.length];
		for(Entry<String,String> e : dictEntries) {
				for(int j=0; j<values.length; j++) {
					if(values[j].equals(e.getValue())) {
						checked[j]=true;
					}
				}
			}
		for(int j=0; j<checked.length; j++)//;
		
		org.junit.Assert.assertEquals("Verifying entries() contains entries with Values:{\"A\",\"B\"}", (Object)(true), (Object)(checked[j]));
	}

}
