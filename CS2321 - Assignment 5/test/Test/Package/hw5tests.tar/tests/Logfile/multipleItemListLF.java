import org.junit.*;
import jug.*;
import cs2321.*;
import net.datastructures.*;
import java.util.Random;

@jug.SuiteName("Multiple Item List - Entries:{[\"3\",\"C\"],[\"1\",\"A\"],[\"2\",\"B\"],[\"1\",\"D\"]}")
public class multipleItemListLF {

	private Logfile<String, String> TARGET = init();
	private Logfile<String, String> T = init();

	public Logfile<String, String> init() {
		return new Logfile<String, String>();
	}

	@Before
	public void setup() throws Throwable {
		TARGET.insert("3","C");
			TARGET.insert("1","A");
			TARGET.insert("2","B");
			TARGET.insert("1","D");
	}

	@org.junit.Test(timeout=60000)
	@jug.TestName("Verifying entries() count = 4")
	public void Test1() throws Throwable {
		int count = 0;
		for(Entry<String, String> e : TARGET.entries())
				count++;
		
		org.junit.Assert.assertEquals("Verifying entries() count = 4", (Object)(4), (Object)(count));
	}

	@org.junit.Test()
	@jug.TestName("Verifying entries() returns entries with Keys:{\"1\",\"1\",\"2\",\"3\"}")
	public void Test2() throws Throwable {
		String [] keys = {"1","2","1","3"}
		;
		Iterable<Entry<String, String>> dictEntries = TARGET.entries();
		boolean [] checked = new boolean[keys.length];
		for(Entry<String,String> e : dictEntries) {
				for(int j=0; j<keys.length; j++) {
					if(keys[j].equals(e.getKey()) && checked[j]==false) {
						checked[j]=true;
					}
				}
			}
		for(int j=0; j<checked.length; j++)//;
		
		org.junit.Assert.assertEquals("Verifying entries() returns entries with Keys:{\"1\",\"1\",\"2\",\"3\"}", (Object)(true), (Object)(checked[j]));
	}

	@org.junit.Test()
	@jug.TestName("Verifying entries() returns entries with Values:{\"A\",\"B\",\"C\",\"D\"}")
	public void Test3() throws Throwable {
		String [] values = {"A","B","C","D"}
		;
		Iterable<Entry<String, String>> dictEntries = TARGET.entries();
		boolean [] checked = new boolean[values.length];
		for(Entry<String,String> e : dictEntries) {
				for(int j=0; j<values.length; j++) {
					if(values[j].equals(e.getValue()) && checked[j]==false) {
						checked[j]=true;
					}
				}
			}
		for(int j=0; j<checked.length; j++)//;
		
		org.junit.Assert.assertEquals("Verifying entries() returns entries with Values:{\"A\",\"B\",\"C\",\"D\"}", (Object)(true), (Object)(checked[j]));
	}

}
